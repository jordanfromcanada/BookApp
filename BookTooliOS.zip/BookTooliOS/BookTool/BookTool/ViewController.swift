//
//  ViewController.swift
//  BookTool
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .red
        
        view.addSubview(button)
        button.center = view.center
        button.addTarget(self, action: #selector(didTapButton), for: .touchUpInside)
    }
    
    private let button: UIButton = {
        let button = UIButton(frame: CGRect(x: 0, y: 0, width: 200, height: 50))
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = .systemRed
        button.setTitle("Tap me", for: .normal)
        return button
    }()
    
    @IBAction func didTapButton() {
        // try to instantiate viewcontroller with this ID
        guard let vc = storyboard?.instantiateViewController(identifier: "HomeScreen") as? HomeScreenViewController else {
            return
            }
        
        // avoid ability for user to swipe down
        vc.modalPresentationStyle = .fullScreen
        
        // transition style
        vc.modalTransitionStyle = .flipHorizontal
        present(vc, animated: true)
    }

}

